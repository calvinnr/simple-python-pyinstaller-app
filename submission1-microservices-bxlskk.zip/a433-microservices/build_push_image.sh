#!/bin/bash

#Membuat docker image dengan nama image item-app dengan tag v1
docker build -t item-app:v1 .

#Melihat daftar image
docker images
sleep 10

#Mengubah nama image agar sesuai dengan format Github Packages
docker tag item-app:v1 ghcr.io/calvinnr/item-app:v1

#Menyimpan PAT sebagai environment
export CR_PAT=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

#Login ke Github Package
echo $CR_PAT | docker login ghcr.io -u calvinnr --password-stdin

#Menggungah image yang telah dibuat ke Github Packages
docker push ghcr.io/calvinnr/item-app:v1


