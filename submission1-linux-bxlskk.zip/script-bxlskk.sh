#!/bin/sh

 

# true sebagai penanda bahwa perulangan ini berlangsung terus
while true
do
  echo Menampilkan ukuran memory pada sistem dalam satuan megabytes.
  free --mega
  echo Tunda 3 detik
  sleep 3
  echo Membuat baris baru
  echo

  echo Menampilkan penggunaan ruang disk pada filesystem dalam satuan gigabytes.
  df -hBG
  echo Tunda 3 detik
  sleep 3
  echo Membuat baris baru
  echo

  echo Menampilkan penggunaan ruang disk pada filesystem hanya untuk kolom Filesystem dan Use% ditampilkan juga nama kolomnya serta tanpa menyertakan tmpfs.
  df -hx tmpfs --output=source,pcent
  echo Tunda 1 menit
  sleep 1m
  echo Membuat baris baru
  echo

done
