#!/bin/sh
 

# true sebagai penanda bahwa perulangan ini berlangsung terus
while true
do
  # Menampilkan ukuran memory pada sistem dalam satuan megabytes.
  free -m
  # tunda 3 detik
  sleep 3
  # membuat baris baru
  echo

  # Menampilkan penggunaan ruang disk pada filesystem dalam satuan gigabytes.
  df --human-readable --exclude-type=tmpfs
  # tunda 3 detik
  sleep 3
  # membuat baris baru
  echo

  # Menampilkan penggunaan ruang disk pada filesystem hanya untuk kolom Filesystem dan Use% (ditampilkan juga nama kolomnya) serta tanpa menyertakan tmpfs.
  df --human-readable --exclude-type=tmpfs --output=source,pcent
  # tunda 1 menit
  sleep 1m

done
