#!/bin/sh


# true sebagai penanda bahwa perulangan ini berlangsung terus
while true
do
  echo Informasi penggunaan disk
  sudo journalctl --disk-usage
  echo Silahkan baca log berikut selama 30 detik
  sleep 30
  echo Membuat baris baru....
  echo

  echo Mengurangi size journalctl log
  sudo journalctl --vacuum-size=10M
  echo Silahkan menunggu proses selama 10 detik
  sleep 10
  echo Membuat baris baru....
  echo

  echo Informasi penggunaan disk
  sudo journalctl --disk-usage
  echo Silahkan baca log berikut selama 30 detik
  sleep 30
  echo Membuat baris baru....
  echo

done
